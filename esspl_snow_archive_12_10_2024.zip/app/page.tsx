import FilterPanel from "./component/FilterComponent/FilterPanel";
import FilterPanelInitDataLoader from "./component/FilterComponent/FilterPanel_InitDataLoader";
import InitDataLoading from "./component/InitDataLoading";
import { MainStoreProvider } from "./component/MainStoreProvider";
import TablePagingComponent from "./component/TablePaggingComponent";
import SecondPage from "./SecondPage";

export default function Home() {
  const typeoffilter = 1;
  return (
    <>
      <>
        <MainStoreProvider>
          <InitDataLoading />

          <div className="flex-shrink">
            <FilterPanelInitDataLoader filterType={typeoffilter} />
            <FilterPanel typeOfFilter={typeoffilter} />
          </div>

          <div className="h-96 grow overflow-scroll">
            <SecondPage></SecondPage>
          </div>
          <div className="flex flex-none justify-center">
            <TablePagingComponent />
          </div>
          {/* <FilterPanel />
          <div className="flex-grow rounded bg-white h-96 overflow-auto ">
            <IncidentTable />
          </div>
          <div className="flex flex-row gap-3 items-center justify-center p-3 bg-accent rounded">
            <button>Fetch Async</button>
          </div> */}
        </MainStoreProvider>
      </>
    </>
  );
}
