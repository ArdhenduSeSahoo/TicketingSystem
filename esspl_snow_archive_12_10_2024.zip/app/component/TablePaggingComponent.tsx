"use client";

import { useAppDispatch, useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import {
  selectFinalColumnListIncident,
  selectIncidentTableData,
} from "@/lib/Redux/Selectors/MainPage/MainPageSelector";
import {
  fetchNextPageData,
  fetchPrevPageData,
} from "@/lib/Redux/Slices/MainPage/IncidentTableDataSlice";

export default function TablePagingComponent() {
  const dispatch = useAppDispatch();
  const incidentData = useAppSelector(selectIncidentTableData);
  const incidentColumnList = useAppSelector(selectFinalColumnListIncident);
  let pageRangeTo = incidentData.skip + incidentColumnList.NumberOfDataPerPage;
  if (
    incidentData.dataList?.totalCount &&
    pageRangeTo > incidentData.dataList?.totalCount
  ) {
    pageRangeTo = incidentData.dataList?.totalCount;
  }
  const PageRange = `${incidentData.skip} to ${pageRangeTo}`;
  function btn_FetchNext() {
    dispatch(fetchNextPageData());
  }
  function btn_fetchPrevData() {
    dispatch(fetchPrevPageData());
  }
  const disableProps_Prev = incidentData.fetchPrev
    ? {
        className: "btn join-item btn-sm justify-items-center",
        disabled: false,
      }
    : {
        className: "btn join-item btn-sm justify-items-center btn-disabled",
        disabled: true,
      };
  const disableProps_Next = incidentData.fetchNext
    ? {
        className: "btn join-item btn-sm justify-items-center",
        disabled: false,
      }
    : {
        className: "btn join-item btn-sm justify-items-center btn-disabled",
        disabled: true,
      };
  return (
    <div className="p-2">
      <div className="join items-center justify-items-center gap-2 bg-gray-100">
        <button {...disableProps_Prev} onClick={btn_fetchPrevData}>
          <span>Prev</span>
        </button>
        <div className="join-item">{PageRange}</div>
        <div className="join-item">
          | Total {incidentData.dataList?.totalCount}
        </div>
        <button {...disableProps_Next} onClick={btn_FetchNext}>
          <span>Next</span>
        </button>
      </div>
    </div>
  );
}
