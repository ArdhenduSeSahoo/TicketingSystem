"use client";
import { IncidentDefaultColumnConfig } from "@/lib/DefaultData/IncidentDefaultColumns";
import { ColumnConfig } from "@/lib/Models/ColumnConfigModel";
import { useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import {
  selectFinalColumnListIncident,
  selectIncidentTableData,
} from "@/lib/Redux/Selectors/MainPage/MainPageSelector";
import Image from "next/image";
import Link from "next/link";
//import nodataimage from "/images/DataNotFound.PNG";

export default function IncidentTable() {
  const incidentcolumns = useAppSelector(selectFinalColumnListIncident);
  const incidentData = useAppSelector(selectIncidentTableData);

  let colList = incidentcolumns.columnConfigList;
  if (colList.length === 0) {
    colList = IncidentDefaultColumnConfig;
  }
  const columnList = colList.map((val: ColumnConfig, index: number) => {
    return (
      <th key={index} scope="col" className="min-w-10 px-6 py-3">
        <div className="flex items-center justify-center">{val.name}</div>
      </th>
    );
  });
  const DataItems = [];
  if (incidentData.errorFound) {
    DataItems.push(
      <tr>
        <td colSpan={100}>
          <div className="flex items-center justify-center">
            <div className="">{incidentData.errorMessage} </div>
          </div>
        </td>
      </tr>,
    );
  } else if (incidentData.loadingData) {
    //loader
    const columnList_loader = colList.map(
      (val: ColumnConfig, index: number) => {
        return (
          <td key={index}>
            <div className="z-10 flex animate-pulse items-center justify-center">
              <div className="h-7 w-32 rounded-md bg-gray-300"></div>
            </div>
          </td>
        );
      },
    );

    for (let i = 0; i < 10; i++) {
      DataItems.push(
        <tr
          key={i}
          className="border-b bg-white font-medium text-black hover:bg-blue-100"
        >
          <th scope="col" className="p-4">
            <div className="flex items-center">
              <input
                id="checkbox-all-search"
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 bg-gray-100 text-blue-600 focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:ring-offset-gray-800 dark:focus:ring-blue-600 dark:focus:ring-offset-gray-800"
              />
              <label htmlFor="checkbox-all-search" className="sr-only">
                checkbox
              </label>
            </div>
          </th>
          {columnList_loader}
        </tr>,
      );
    }
  } else {
    //show data
    if (
      incidentData.dataList === null ||
      incidentData.dataList === undefined ||
      incidentData.dataList.items.length <= 0
    ) {
      DataItems.push(
        <tr>
          <td colSpan={100}>
            <div className="flex items-center justify-center p-5">
              <Image
                alt="no data"
                src={"/images/DataNotFound.PNG"}
                height={300}
                width={300}
                className="object-cover"
              />
            </div>
          </td>
        </tr>,
      );
    } else {
      incidentData.dataList?.items.forEach((itm, index) => {
        const cellData = [];
        let keyval = 1;
        for (const [dkey, value] of Object.entries(itm)) {
          //console.log(`${key}: ${value}`);
          if (typeof value === "object") {
            let has_sub_data = false;
            for (const [skey, svalue] of Object.entries(value)) {
              //console.log(`${skey}: ${svalue}`);
              cellData.push(<td key={keyval}>{String(svalue)}</td>);
              keyval++;
              has_sub_data = true;
              break;
            }
            if (!has_sub_data) {
              cellData.push(<td>NA</td>);
            }
          } else {
            if (dkey === "number") {
              cellData.push(
                <td key={keyval} className="pl-1">
                  <Link
                    href={{
                      pathname: `/incidentdetails/${value}`,
                    }}
                    scroll={false}
                    target="_blank"
                    className="text-blue-500"
                  >
                    {String(value)}
                  </Link>
                </td>,
              );
            } else {
              cellData.push(
                <td key={keyval} className="pl-2">
                  {String(value)}
                </td>,
              );
            }

            keyval++;
          }
        }
        keyval = 1;
        DataItems.push(
          <tr
            key={index}
            className="border-b bg-white font-medium text-black hover:bg-blue-100"
          >
            <th scope="col" className="p-4">
              <div className="flex items-center">
                <input
                  id="checkbox-all-search"
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-300 bg-gray-100 text-blue-600 focus:ring-blue-500 dark:focus:ring-blue-600"
                />
                <label htmlFor="checkbox-all-search" className="sr-only">
                  checkbox
                </label>
              </div>
            </th>
            {cellData}
          </tr>,
        );
      });
    }
  }

  return (
    <>
      <div className="relative">
        <table className="w-full text-left text-xs text-gray-500 rtl:text-right">
          <thead className="sticky top-0 rounded-tl-md rounded-tr-md bg-gray-700 text-xs uppercase text-white">
            <tr>
              <th scope="col" className="p-4">
                <div className="flex items-center">
                  <input
                    id="checkbox-all-search"
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 ring-offset-gray-800 focus:ring-2 focus:ring-blue-500 focus:ring-offset-gray-800"
                  />
                  <label htmlFor="checkbox-all-search" className="sr-only">
                    checkbox
                  </label>
                </div>
              </th>

              {columnList}
            </tr>
          </thead>
          <tbody>{DataItems}</tbody>
        </table>
      </div>
    </>
  );
}
