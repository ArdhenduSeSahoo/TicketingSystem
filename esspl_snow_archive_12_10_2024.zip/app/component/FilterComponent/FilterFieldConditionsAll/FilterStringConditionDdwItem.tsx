"use client";

import {
  FilterStringCondition,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import { useAppDispatch } from "@/lib/Redux/Hooks/HomePageHook";
import { changeFilterCondition } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";

export interface IFilterStringConditionDdwItem {
  filterDataColumn: FilterStringCondition;
  filterRow: FilterUIData;
}

export default function FilterStringConditionDdwItem(
  props: IFilterStringConditionDdwItem,
) {
  const dispatch = useAppDispatch();
  function item_click() {
    dispatch(
      changeFilterCondition({
        filterRow: props.filterRow,
        newFilterCondition: props.filterDataColumn,
      }),
    );
  }
  const old_design = (
    <li
      onClick={item_click}
      className="flex items-start justify-start overflow-hidden rounded-lg px-2 text-start hover:bg-gray-200"
    >
      {props.filterDataColumn.name}
    </li>
  );
  return old_design;
}
