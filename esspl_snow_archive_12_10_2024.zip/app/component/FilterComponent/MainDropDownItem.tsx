"use client";

import {
  FilterColumnValue,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import { useAppDispatch } from "@/lib/Redux/Hooks/HomePageHook";
import { changeFilterColumn } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";

export interface IMainDropDownItemProps {
  filterDataColumn: FilterColumnValue;
  filterRow: FilterUIData;
}

export default function MainDropDownItem(props: IMainDropDownItemProps) {
  const dispatch = useAppDispatch();
  function item_click() {
    dispatch(
      changeFilterColumn({
        filterRow: props.filterRow,
        newFilterColumn: props.filterDataColumn,
      }),
    );
  }
  const old_design = (
    <li
      onClick={item_click}
      className="flex items-start justify-start overflow-hidden rounded-lg px-2 text-start hover:bg-gray-200"
    >
      {props.filterDataColumn.name}
    </li>
  );
  return old_design;
}
