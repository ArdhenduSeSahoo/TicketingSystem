"use client";
import { useAppDispatch, useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import { selectFilterFinalDataQuery } from "@/lib/Redux/Selectors/MainPage/MainPageSelector";
import { restoreFromLocalStore } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";
import { useEffect } from "react";

export interface IFilterPanelInitDataLoaderProps {
  filterType: number;
}

export default function FilterPanelInitDataLoader(
  props: IFilterPanelInitDataLoaderProps,
) {
  const dispatch = useAppDispatch();
  const FilterFinalDataQuery = useAppSelector(selectFilterFinalDataQuery);
  useEffect(() => {
    dispatch(
      restoreFromLocalStore({
        filterType: props.filterType,
        incidentFilter: FilterFinalDataQuery.incidentFilterUIData,
        requestFilter: FilterFinalDataQuery.requestNowFilterUIData,
      }),
    );
  });
  return <div></div>;
}
