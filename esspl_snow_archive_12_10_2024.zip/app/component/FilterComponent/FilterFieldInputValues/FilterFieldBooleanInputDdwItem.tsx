"use client";

import {
  FilterBooleanInput,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import { useAppDispatch } from "@/lib/Redux/Hooks/HomePageHook";
import { changeFilterUserInput } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";

export interface IFilterFieldBooleanInputDdwItem {
  filterDataField: FilterBooleanInput;
  filterRow: FilterUIData;
}

export default function FilterFieldBooleanInputDdwItem(
  props: IFilterFieldBooleanInputDdwItem,
) {
  const dispatch = useAppDispatch();
  function item_click() {
    console.log(JSON.stringify(props.filterDataField));
    dispatch(
      changeFilterUserInput({
        filterRow: props.filterRow,
        newFilterUserDataInput: props.filterDataField,
      }),
    );
  }
  const old_design = (
    <li
      onClick={item_click}
      className="flex items-start justify-start overflow-hidden rounded-lg px-2 text-start hover:bg-gray-200"
    >
      {props.filterDataField.name}
    </li>
  );
  return old_design;
}
