"use client";
import {
  FilterDataFieldInput,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import FilterFieldDataFieldInputDdwItem from "./FilterFieldDataFieldInputDdwItem";
import { useAppDispatch, useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import { fetchFilterDataField } from "@/lib/Redux/Slices/commonSlices/FilterDataFieldDdwSlice";
import {
  selectFilterDataFieldDdw,
  selectFilterUIDataAll,
} from "@/lib/Redux/Selectors/MainPage/MainPageSelector";

export interface IFilterFieldBooleanInputProps {
  filterUIData: FilterUIData;
}

export default function FilterFieldDataFieldInputDdw(
  props: IFilterFieldBooleanInputProps,
) {
  const dispatch = useAppDispatch();
  const selectFilterDataFetchDataList = useAppSelector(
    selectFilterDataFieldDdw,
  );
  const selectfilterUiData = useAppSelector(selectFilterUIDataAll);
  let selectedItem = "";
  let menuItems: JSX.Element[] = [];
  if (props.filterUIData.filterType === 1) {
    //console.log(selectFilterDataFetchDataList);

    if (selectFilterDataFetchDataList.isLoading) {
      menuItems = [];
      menuItems.push(
        <li
          key={0}
          className="flex items-start justify-center overflow-hidden rounded-lg p-3 text-start"
        >
          <span className="loading loading-spinner text-primary"></span>
        </li>,
      );
    } else {
      const find_data_fetch_item =
        selectFilterDataFetchDataList.filterDataFetchList.find((itm) => {
          return (
            itm.filterColumnValue.name === props.filterUIData.firstFilter?.name
          );
        });
      if (
        find_data_fetch_item !== undefined &&
        find_data_fetch_item.filterDatainputFields !== undefined
      ) {
        menuItems = [];
        find_data_fetch_item.filterDatainputFields.forEach((itm, index) => {
          menuItems.push(
            <FilterFieldDataFieldInputDdwItem
              filterDataField={itm}
              filterRow={props.filterUIData}
              key={index}
            />,
          );
        });
      } else {
        menuItems = [];
        menuItems.push(
          <li
            key={0}
            className="flex items-start justify-center overflow-hidden rounded-lg p-3 text-start"
          >
            No Data Found
          </li>,
        );
      }
    }
    try {
      selectfilterUiData.incidentFilterUIData?.forEach((itm) => {
        if (itm.id === props.filterUIData.id) {
          if (itm.inputValue !== null)
            selectedItem = (itm.inputValue as FilterDataFieldInput).name;
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  function btn_clicked() {
    if (props.filterUIData.firstFilter !== null) {
      dispatch(fetchFilterDataField(props.filterUIData.firstFilter));
    }
  }
  return (
    <div>
      <div className="dropdown">
        <div
          tabIndex={0}
          role="button"
          onClick={btn_clicked}
          className="flex h-8 min-w-40 max-w-64 flex-row items-center justify-between overflow-clip rounded-md bg-white p-1 px-2"
        >
          <p className="truncate">{selectedItem}</p>
          <span>
            <svg
              fill="#000000"
              height="15"
              width="15"
              version="1.1"
              id="Layer_1"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 512.011 512.011"
            >
              <g>
                <g>
                  <path
                    d="M505.755,123.592c-8.341-8.341-21.824-8.341-30.165,0L256.005,343.176L36.421,123.592c-8.341-8.341-21.824-8.341-30.165,0
			s-8.341,21.824,0,30.165l234.667,234.667c4.16,4.16,9.621,6.251,15.083,6.251c5.462,0,10.923-2.091,15.083-6.251l234.667-234.667
			C514.096,145.416,514.096,131.933,505.755,123.592z"
                  />
                </g>
              </g>
            </svg>
          </span>
        </div>
        <ul
          tabIndex={0}
          className="dropdown-content z-50 mt-1 max-h-80 min-w-40 max-w-60 overflow-y-scroll rounded-box bg-gray-100 p-2 text-black shadow"
        >
          {menuItems}
        </ul>
      </div>
    </div>
  );
}
