import * as React from "react";

export interface ISearchItemProps {}

export default function SearchItem(props: ISearchItemProps) {
  return (
    <div>
      <a>
        <div className="flex flex-col h-20 p-1 bg-gray-100 rounded-md overflow-clip mx-1 hover:bg-blue-100">
          <p className="truncate font-semibold text-sm">
            Descriptions askdlf asdkjal skd flaksdjf laksjfoiwejf sdkl
          </p>
          <p className="text-sm">ID: INSE-232442s</p>
        </div>
      </a>
    </div>
  );
}
