"use client";
import * as React from "react";
import { Dialog, DialogBackdrop, DialogPanel } from "@headlessui/react";
import ConfigContentComponent from "./ConfigContentComponent";
import SaveButtonConfigTable from "./BtnSaveConfigTable";

import { DialogCloseAction } from "@/lib/OtherFunctions/TableConfigCloseBtnAction";
import { useAppDispatch, useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import { AddColumns } from "@/lib/Redux/Slices/MainPage/IncidentColumnsSlice";
import {
  selectFinalColumnListIncident,
  selectFinalSelectedItem,
} from "@/lib/Redux/Selectors/MainPage/MainPageSelector";
import {
  addItemToRightSideList,
  addToAllColumnList,
  removeAllColumnList,
  removeAllFinalModifyItem,
  removeAllSelectedItem,
} from "@/lib/Redux/Slices/commonSlices/SelectedItemSlice";
import { fetchIncidentTableData } from "@/lib/Redux/Slices/MainPage/IncidentTableDataSlice";
import { IncidentAllColumnnConfig } from "@/lib/DefaultData/FilterData/IncidentAllColumnConfigData";
import { IncidentDefaultColumnConfig } from "@/lib/DefaultData/IncidentDefaultColumns";

export default function ModalTableConfig() {
  const [isOpen, setIsOpen] = React.useState(false);
  const dispatch = useAppDispatch();
  const selectFinalColumnList = useAppSelector(selectFinalSelectedItem);
  const finalSelectedItems = useAppSelector(selectFinalColumnListIncident);
  function closeBtnclick() {
    DialogCloseAction(dispatch);
    setIsOpen(false);
  }

  function btn_Save_Clicked() {
    dispatch(AddColumns(selectFinalColumnList));
    dispatch(removeAllSelectedItem());
    dispatch(removeAllFinalModifyItem());
    dispatch(removeAllColumnList());
    dispatch(fetchIncidentTableData());
    setIsOpen(false);
  }

  function btn_OpenDialog() {
    dispatch(addToAllColumnList(IncidentAllColumnnConfig));
    let selected_Columns = finalSelectedItems.columnConfigList;
    if (selected_Columns.length === 0) {
      selected_Columns = IncidentDefaultColumnConfig;
    }
    dispatch(removeAllSelectedItem());
    dispatch(removeAllFinalModifyItem());
    dispatch(addItemToRightSideList(selected_Columns));
    setIsOpen(true);
  }
  return (
    <div>
      <button onClick={btn_OpenDialog} className="btn btn-sm">
        Config
      </button>
      <Dialog open={isOpen} onClose={() => null} className="relative z-50">
        <DialogBackdrop className="fixed inset-0 bg-black/30" />
        <div className="fixed inset-0 flex w-screen items-center justify-center p-4">
          <DialogPanel className="max-w-lg">
            <div className="pointer-events-auto flex max-h-full w-full flex-col overflow-hidden rounded-xl border bg-white shadow-sm">
              <div className="flex items-center justify-between border-b px-4 py-3">
                <h3 className="font-bold">Table Config</h3>
                {/* <CloseButton2 /> */}
              </div>
              <ConfigContentComponent />
              <div className="modal-action flex items-center justify-end gap-x-2 border-t px-4 py-3">
                {/* <CloseButton /> */}
                <button
                  className="btn btn-error btn-sm"
                  onClick={closeBtnclick}
                >
                  Cancel
                </button>
                {/* <SaveButtonConfigTable /> */}
                <button
                  className="btn btn-info btn-sm"
                  onClick={btn_Save_Clicked}
                >
                  Save
                </button>
              </div>
            </div>
          </DialogPanel>
        </div>
      </Dialog>
    </div>
  );
}
