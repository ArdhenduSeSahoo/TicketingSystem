"use client";
import { IncidentDefaultColumnConfig } from "@/lib/DefaultData/IncidentDefaultColumns";
import { useAppDispatch, useAppSelector } from "@/lib/Redux/Hooks/HomePageHook";
import { selectFinalColumnListIncident } from "@/lib/Redux/Selectors/MainPage/MainPageSelector";
import { loadInitStateData } from "@/lib/Redux/Slices/MainPage/IncidentColumnsSlice";
import { fetchIncidentTableData } from "@/lib/Redux/Slices/MainPage/IncidentTableDataSlice";
import { useEffect } from "react";

export default function InitDataLoading() {
  const incidentTableColumns = useAppSelector(selectFinalColumnListIncident);
  const dispatch = useAppDispatch();
  useEffect(() => {
    // const localstorecolumnconfig = localStorage.getItem(
    //   IncidentColumnConfigKey,
    // );
    // if (localstorecolumnconfig?.trim().length !== 0) {
    //   try {
    //     const columnConfigList = JSON.parse(
    //       localstorecolumnconfig!,
    //     ) as ColumnConfig[];
    //     dispatch(loadInitStateData(columnConfigList));
    //   } catch (error) {
    //     console.error(error);
    //     dispatch(loadInitStateData(IncidentDefaultColumnConfig));
    //   }
    // } else {
    //   dispatch(loadInitStateData(IncidentDefaultColumnConfig));
    // }
    //dispatch(fetchIncidentTableData());
    if (incidentTableColumns.columnConfigList.length === 0) {
      dispatch(loadInitStateData(IncidentDefaultColumnConfig));
      setTimeout(() => {
        dispatch(fetchIncidentTableData());
      }, 500);
    } else {
      dispatch(fetchIncidentTableData());
    }
  });
  return <></>;
}
