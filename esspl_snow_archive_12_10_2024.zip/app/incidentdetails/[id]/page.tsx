"use client";
import { useState } from "react";

export default function Page({ params }: { params: { id: string } }) {
  const [data, setData] = useState(null);
  const [isLoading, setLoading] = useState(true);
  return <div>My Post: {params.id}</div>;
}
