import * as React from "react";
import { MainStoreProvider } from "../component/MainStoreProvider";
import InitDataLoading from "../component/InitDataLoading";
import FilterPanelInitDataLoader from "../component/FilterComponent/FilterPanel_InitDataLoader";
import FilterPanel from "../component/FilterComponent/FilterPanel";
import SecondPage from "../SecondPage";
import TablePagingComponent from "../component/TablePaggingComponent";

// export interface IAllRequestsProps {}

export default function AllRequests() {
  const typeoffilter = 1;
  return (
    <div>
      <MainStoreProvider>
        <InitDataLoading />

        <div className="flex-shrink">
          <FilterPanelInitDataLoader filterType={typeoffilter} />
          <FilterPanel typeOfFilter={typeoffilter} />
        </div>

        <div className="h-96 grow overflow-scroll">
          <SecondPage></SecondPage>
        </div>
        <div className="flex flex-none justify-center">
          <TablePagingComponent />
        </div>
        {/* <FilterPanel />
          <div className="flex-grow rounded bg-white h-96 overflow-auto ">
            <IncidentTable />
          </div>
          <div className="flex flex-row gap-3 items-center justify-center p-3 bg-accent rounded">
            <button>Fetch Async</button>
          </div> */}
      </MainStoreProvider>
    </div>
  );
}
