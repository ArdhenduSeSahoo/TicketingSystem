export interface ColumnConfig {
  name: string;
  queryG: string;
}
