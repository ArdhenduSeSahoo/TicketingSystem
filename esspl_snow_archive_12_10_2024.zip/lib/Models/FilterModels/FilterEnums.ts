export enum EnumFilterConditionType {
  stringType,
  dateTimeType,
  dataFetchType,
  booleanType,
}
export enum EnumWhereConditionType {
  AndCondition,
  OrCondition,
}
