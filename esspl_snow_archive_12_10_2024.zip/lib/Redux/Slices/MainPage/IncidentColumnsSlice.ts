import { ColumnConfig } from "@/lib/Models/ColumnConfigModel";
import { IncidentColumnListSliceModel } from "@/lib/Models/IncidentListModel";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initstate: IncidentColumnListSliceModel = {
  columnConfigList: [],
  gQuery: "",
  NumberOfDataPerPage: 100,
};
const incidentColumns = createSlice({
  name: "IncidentColumns",
  initialState: initstate,
  reducers: {
    loadInitStateData: (state, action: PayloadAction<ColumnConfig[]>) => {
      let generategquery = "";
      action.payload.forEach((que) => {
        generategquery += que.queryG + "\n";
      });
      state.columnConfigList = action.payload;
      state.gQuery = generategquery;
    },
    AddColumns: (state, action: PayloadAction<ColumnConfig[]>) => {
      let generategquery = "";
      action.payload.forEach((que) => {
        generategquery += que.queryG + "\n";
      });
      state.columnConfigList = action.payload;
      state.gQuery = generategquery;
    },
    setNumberOfDataPerPage: (state, action: PayloadAction<number>) => {
      state.NumberOfDataPerPage = action.payload;
    },
  },
});

export default incidentColumns.reducer;
export const { loadInitStateData, AddColumns } = incidentColumns.actions;
