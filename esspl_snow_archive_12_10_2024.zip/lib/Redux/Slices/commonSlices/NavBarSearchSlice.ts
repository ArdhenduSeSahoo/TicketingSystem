import { createSlice } from "@reduxjs/toolkit";
interface NavBarSearchModel {
  number: string;
  shortDescription: string;
}
const initVal: NavBarSearchModel[] = [];
const NavBarSearchSlice = createSlice({
  name: "NavBarSearch",
  initialState: initVal,
  reducers: {},
});
export default NavBarSearchSlice.reducer;
export const {} = NavBarSearchSlice.actions;
