import axios from "axios";

export const graphQlAxios = axios.create({
  baseURL: "https://localhost:7139/graphql/",
  method: "post",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
});

export const AxiosGraphQlPostCall = async (query: string) => {
  // let retval = null;
  // try {
  //   retval = await graphQlAxios
  //     .post("", { query: query })
  //     .then((response) => ({ response }))
  //     .catch((error) => ({ error }));
  // } catch (error) {
  //   console.log(error);
  // }
  return await graphQlAxios
    .post("", { query: query })
    .then((response) => ({ response }))
    .catch((error) => ({ error }));
};

export function hasResponseError(response: any): string {
  let errorlist = "";
  if (response?.data.errors) {
    (response?.data.errors as Array<any>).forEach((element) => {
      errorlist += element.message;
    });
  }
  return errorlist;
}
