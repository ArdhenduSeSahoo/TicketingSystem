import { call, takeLatest, select, put } from "redux-saga/effects";
import {
  IncidentTableData_fetchIncidentTableData,
  IncidentTableData_fetchNextPageData,
  IncidentTableData_fetchPrevPageData,
} from "../SagaActionKeys";
import {
  selectFilterFinalDataQuery,
  selectFinalColumnListIncident,
  selectIncidentTableData,
} from "../../Redux/Selectors/MainPage/MainPageSelector";
import {
  IncidentColumnListSliceModel,
  IncidentTableDataList,
  IncidentTableDataModels,
} from "@/lib/Models/IncidentListModel";
import {
  AxiosGraphQlPostCall,
  hasResponseError,
} from "../../AxiosFiles/AxiosGraphQlCall";
import {
  incidentQueryTemplate,
  PlaceholderAllColumn,
  PlaceholderSkip,
  PlaceholderTake,
  PlaceholderWhereCondition,
} from "@/lib/DefaultData/IncidentQueryTemplet";
import { ColumnConfig } from "@/lib/Models/ColumnConfigModel";
import { IncidentDefaultColumnConfig } from "@/lib/DefaultData/IncidentDefaultColumns";
import { fetchCompleteIncidentTableData } from "@/lib/Redux/Slices/MainPage/IncidentTableDataSlice";
import { FilterDataFinalRun } from "@/lib/Models/FilterModels/FilterModels";

function* fetchDataResolver() {
  yield fetchIncidentTableDataResolver({ prev: false, next: false });
}
function* fetchDataResolverNextPage() {
  yield fetchIncidentTableDataResolver({ prev: false, next: true });
}

function* fetchDataResolverPrevPage() {
  yield fetchIncidentTableDataResolver({ prev: true, next: false });
}

function* fetchIncidentTableDataResolver(parm: {
  prev: boolean;
  next: boolean;
}) {
  const collomList: IncidentColumnListSliceModel = yield select(
    selectFinalColumnListIncident,
  );

  const selectincidentDataList: IncidentTableDataList = yield select(
    selectIncidentTableData,
  );
  const selectincidentFinalWhereConditions: FilterDataFinalRun = yield select(
    selectFilterFinalDataQuery,
  );
  const incidentDataList = { ...selectincidentDataList };

  let gQueryI = collomList.gQuery;
  if (gQueryI.trim().length === 0) {
    gQueryI = prepareDefaultQuery(IncidentDefaultColumnConfig);
  }
  if (gQueryI.length !== 0) {
    let gQuery = (" " + incidentQueryTemplate).slice(1); //for copy variable to variable
    gQuery = gQuery.replace(PlaceholderAllColumn, gQueryI);

    gQuery = gQuery.replace(
      PlaceholderTake,
      collomList.NumberOfDataPerPage.toString(),
    );
    let skipValue = incidentDataList.skip;

    if (parm.next === false && parm.prev === false) {
      skipValue = 0;
      incidentDataList.skip = 0;
    } else if (parm.next === true && parm.prev === false) {
      skipValue = skipValue + collomList.NumberOfDataPerPage;
      console.log(skipValue);
    } else if (parm.next === false && parm.prev === true) {
      skipValue = skipValue - collomList.NumberOfDataPerPage;
      if (skipValue < 0) {
        skipValue = 0;
      }
    }
    gQuery = gQuery.replace(PlaceholderSkip, skipValue.toString());

    const whereConditions =
      selectincidentFinalWhereConditions.incidentFilterFinalQuery;
    if (whereConditions !== null) {
      gQuery = gQuery.replace(PlaceholderWhereCondition, whereConditions);
    } else {
      gQuery = gQuery.replace(PlaceholderWhereCondition, "{}");
    }
    try {
      const { response } = yield call(AxiosGraphQlPostCall, gQuery);
      const getErrorMessage = hasResponseError(response);
      if (getErrorMessage.length === 0) {
        const incidentData = response?.data?.data
          ?.incidents as IncidentTableDataModels;
        incidentDataList.dataList = incidentData;
        incidentDataList.errorFound = false;
        incidentDataList.errorMessage = "";
        incidentDataList.skip = skipValue;
        incidentDataList.fetchNext = incidentData.pageInfo.hasNextPage;
        incidentDataList.fetchPrev = incidentData.pageInfo.hasPreviousPage;

        yield put(fetchCompleteIncidentTableData(incidentDataList));
      } else {
        incidentDataList.errorFound = true;
        incidentDataList.errorMessage = getErrorMessage;
        incidentDataList.dataList = null;
        incidentDataList.skip = 0;
        incidentDataList.fetchNext = false;
        incidentDataList.fetchPrev = false;
        yield put(fetchCompleteIncidentTableData(incidentDataList));
      }
    } catch (error) {
      console.error(error);
    }
  }
}

export function* fetchIncidentTableDataWatcher() {
  yield takeLatest(IncidentTableData_fetchIncidentTableData, fetchDataResolver);
}
export function* fetchIncidentTableNextPageDataWatcher() {
  yield takeLatest(
    IncidentTableData_fetchNextPageData,
    fetchDataResolverNextPage,
  );
}
export function* fetchIncidentTablePrevPageDataWatcher() {
  yield takeLatest(
    IncidentTableData_fetchPrevPageData,
    fetchDataResolverPrevPage,
  );
}

function prepareDefaultQuery(columns: ColumnConfig[]): string {
  let querys = "";
  columns.forEach((itm) => {
    querys += itm.queryG + "\n";
  });
  return querys;
}
