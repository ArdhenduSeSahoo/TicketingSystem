export const incrementAsyncRequest = "counter/increment";
export const incidentListKey = "incidentList/fetchIncidentList";
export const IncidentTableData_fetchIncidentTableData =
  "IncidentTableData/fetchIncidentTableData";
export const IncidentTableData_fetchNextPageData =
  "IncidentTableData/fetchNextPageData";
export const IncidentTableData_fetchPrevPageData =
  "IncidentTableData/fetchPrevPageData";
export const FilterDataFieldDDW_fetchFilterDataField =
  "FilterDataFieldDDW/fetchFilterDataField";
