import { all, fork } from "redux-saga/effects";
import {
  fetchIncidentTableDataWatcher,
  fetchIncidentTableNextPageDataWatcher,
  fetchIncidentTablePrevPageDataWatcher,
} from "./MainPageSaga/MainPageSaga";
import { fetchFilterDataWatcher } from "./CommonSaga/FilterSaga";

export function* rootSaga() {
  yield all([
    fork(fetchIncidentTableDataWatcher),
    fork(fetchIncidentTableNextPageDataWatcher),
    fork(fetchIncidentTablePrevPageDataWatcher),
    fork(fetchFilterDataWatcher),
  ]);
}
