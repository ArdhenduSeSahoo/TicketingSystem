export const Api_URL = "https://localhost:7139/graphql/";
