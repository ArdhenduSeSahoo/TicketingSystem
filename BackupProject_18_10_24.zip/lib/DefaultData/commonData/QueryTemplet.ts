export const GQueryTemplate_AllQuery = "#allQuery#";
export const GQueryTemplate = "query {#allQuery#}";
export const filterQueryTemplatePlaceholder = "#fqplace#";
