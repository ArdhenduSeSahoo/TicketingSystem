//
//
//
export enum PageDataType {
  IncidentData = 1,
  RequestData = 2,
}
