export const IncidentColumnConfigKey = "IncidentColumnConfigKey";
