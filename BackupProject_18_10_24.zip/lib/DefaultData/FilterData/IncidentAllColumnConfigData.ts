import { ColumnConfig } from "@/lib/Models/ColumnConfigModel";

export const IncidentAllColumnConfig: ColumnConfig[] = [
  {
    name: "Id",
    queryG: "number",
  },
  {
    name: "Active",
    queryG: "active",
  },
  {
    name: "Opened",
    queryG: "opened",
  },
  {
    name: "Short description",
    queryG: "shortDescription",
  },
  {
    name: "Caller",
    queryG: "caller{userName id}",
  },
];
