import { EnumFilterConditionType } from "../../Models/FilterModels/FilterEnums";
import { FilterColumnValue } from "../../Models/FilterModels/FilterModels";
import { filterQueryTemplatePlaceholder } from "../commonData/QueryTemplet";

export const FilterColumnIncidentAll: FilterColumnValue[] = [
  {
    name: "Active",
    conditionType: EnumFilterConditionType.booleanType,
    inputValueType: EnumFilterConditionType.booleanType,
    inputDataFetchQuery: "",
    tableName: "",
    tablePIdName: "",
    query: "",
    filterQueryTemplate: `active: { ${filterQueryTemplatePlaceholder} }`,
  },
  {
    name: "Short Description",
    conditionType: EnumFilterConditionType.stringType,
    inputValueType: EnumFilterConditionType.stringType,
    inputDataFetchQuery: "",
    tableName: "",
    tablePIdName: "",
    query: "",
    filterQueryTemplate: `shortDescription: { ${filterQueryTemplatePlaceholder} }`,
  },
  {
    name: "Priority",
    conditionType: EnumFilterConditionType.dataFetchType,
    inputValueType: EnumFilterConditionType.dataFetchType,
    inputDataFetchQuery: "",
    tableName: "priority",
    tablePIdName: "id",
    query: `priority(where: { type: { eq: 1 } }){
    items{
      id
      name
      inputValue:id
    }
  }`,
    filterQueryTemplate: `priorityId: { ${filterQueryTemplatePlaceholder} }`,
  },
  {
    name: "Status",
    conditionType: EnumFilterConditionType.dataFetchType,
    inputValueType: EnumFilterConditionType.dataFetchType,
    inputDataFetchQuery: "",
    tableName: "priority",
    tablePIdName: "id",
    query: `priority(take:1000){
    items{
      id
      name
      inputValue:id
    }
  }`,
    filterQueryTemplate: `priorityId: { ${filterQueryTemplatePlaceholder} }`,
  },
];
