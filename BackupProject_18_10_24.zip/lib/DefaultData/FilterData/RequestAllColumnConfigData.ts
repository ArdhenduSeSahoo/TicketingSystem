import { ColumnConfig } from "@/lib/Models/ColumnConfigModel";

export const RequestAllColumnConfig: ColumnConfig[] = [
  {
    name: "Id",
    queryG: "number",
  },
  {
    name: "Active",
    queryG: "active",
  },
  {
    name: "Opened",
    queryG: "opened",
  },
  {
    name: "Short description",
    queryG: "shortDescription",
  },
];
