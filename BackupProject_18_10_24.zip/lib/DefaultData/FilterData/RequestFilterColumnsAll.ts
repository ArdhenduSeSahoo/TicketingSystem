import { EnumFilterConditionType } from "@/lib/Models/FilterModels/FilterEnums";
import { FilterColumnValue } from "@/lib/Models/FilterModels/FilterModels";
import { filterQueryTemplatePlaceholder } from "../commonData/QueryTemplet";

export const FilterColumnRequestAll: FilterColumnValue[] = [
  {
    name: "Number",
    conditionType: EnumFilterConditionType.stringType,
    inputValueType: EnumFilterConditionType.stringType,
    inputDataFetchQuery: "",
    tableName: "",
    tablePIdName: "",
    query: "",
    filterQueryTemplate: `number: { ${filterQueryTemplatePlaceholder} }`,
  },
  {
    name: "Short Description",
    conditionType: EnumFilterConditionType.stringType,
    inputValueType: EnumFilterConditionType.stringType,
    inputDataFetchQuery: "",
    tableName: "",
    tablePIdName: "",
    query: "",
    filterQueryTemplate: `shortDescription: { ${filterQueryTemplatePlaceholder} }`,
  },
];
