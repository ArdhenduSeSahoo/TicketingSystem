//
//
//
//
//
/////////////////////////////////////////////////////////

export const IncidentTableData_fetchIncidentTableData =
  "IncidentTableData/fetchIncidentTableData";
export const IncidentTableData_fetchIncNextPageData =
  "IncidentTableData/fetchIncNextPageData";
export const IncidentTableData_fetchIncPrevPageData =
  "IncidentTableData/fetchIncPrevPageData";

//////////////////////////////////////////////////////////

export const RequestTableData_fetchRequestTableData =
  "RequestTableData/fetchRequestTableData";
export const RequestTableData_fetchNextPageData =
  "RequestTableData/fetchNextReqPageData";
export const RequestTableData_fetchPrevPageData =
  "RequestTableData/fetchPrevReqPageData";

////////////////////////////////////////////////////////

export const FilterDataFieldDDW_fetchFilterDataField =
  "FilterDataFieldDDW/fetchFilterDataField";

export const NavBarSearch_fetchSearchData = "NavBarSearch/fetchSearchData";
