import { RootState } from "../../Stores/MainPageStore/MainPageStore";

export const selectColumnListData = (state: RootState) => state.ColumnLisData;
