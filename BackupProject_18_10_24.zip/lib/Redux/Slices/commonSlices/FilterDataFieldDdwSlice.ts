import {
  FilterColumnValue,
  FilterDataFieldInput,
} from "@/lib/Models/FilterModels/FilterModels";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface IFilterDataFetchDDW {
  filterColumnValue: FilterColumnValue;
  filterDatainputFields: FilterDataFieldInput[];
}

export interface IFilterDataFetchList {
  filterDataFetchList: IFilterDataFetchDDW[];
  isLoading: boolean;
  requestedFilterUIDataToFetch: FilterColumnValue | null;
  hasError: boolean | null;
  errorMessage: string | null;
}

const initData: IFilterDataFetchList = {
  filterDataFetchList: [],
  requestedFilterUIDataToFetch: null,
  isLoading: true,
  hasError: null,
  errorMessage: null,
};
const FilterDataFieldDDW = createSlice({
  name: "FilterDataFieldDDW",
  initialState: initData,
  reducers: {
    fetchFilterDataField: (state, action: PayloadAction<FilterColumnValue>) => {
      state.requestedFilterUIDataToFetch = action.payload;
      state.isLoading = true;
    },
    fetchCompletedFilterDataField: (
      state,
      action: PayloadAction<{
        data: IFilterDataFetchDDW | null;
        hasError: boolean;
        errorMessage: string;
      }>,
    ) => {
      state.errorMessage = action.payload.errorMessage;
      if (action.payload.data !== null) {
        state.filterDataFetchList.push(action.payload.data);
      }

      state.hasError = action.payload.hasError;
      state.isLoading = false;
      //state.requestedFilterUIDataToFetch = null;
    },
    alreadyExistDataField: (state) => {
      state.isLoading = false;
      state.errorMessage = "";
      state.hasError = false;
      console.log("Already exist");
    },
  },
});
export default FilterDataFieldDDW.reducer;
export const {
  fetchFilterDataField,
  fetchCompletedFilterDataField,
  alreadyExistDataField,
} = FilterDataFieldDDW.actions;
