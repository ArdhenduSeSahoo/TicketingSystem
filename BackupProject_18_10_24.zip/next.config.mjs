/** @type {import('next').NextConfig} */
const nextConfig = {
  redirects: () => {
    return [
      {
        source: "/",
        destination: "/allservices/allincidents",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
