import * as React from "react";

export default function Allincidents() {
  return <div>allincidents</div>;
}
