import * as React from "react";

export default function Page() {
  return <div>servidess all. allservices/allincidents</div>;
}
