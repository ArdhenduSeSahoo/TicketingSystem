"use client";
import axios from "axios";
import { useEffect, useState } from "react";

export default function Page({ params }: { params: { id: string } }) {
  const [data, setData] = useState("");
  const [ErrorData, setErrorData] = useState("");
  const [dataJson, setDataJson] = useState(Object);
  const [isLoading, setLoading] = useState(true);

  const hasdata = Object.keys(dataJson).length == 1 ? true : false;
  let jsonss = "";
  useEffect(() => {
    (async () => {
      const qg = `query {
  request(order: {}, skip: 0, take: 100, where: { and: {  number: { eq: "${params.id}", }, }, or: {  } }) {
    items {
      id
      number
      shortDescription
      stage {
        id
        name
      }
      state {
        id
        name
        type
      }
      urgency {
        id
        status
        type
      }
      specialInstructions
      requestState {
        id
        name
      }
      requestedFor {
        id
        name
        userId
      }
      priority {
        id
        name
        type
      }
      price
      openedBy {
        id
        name
        userId
      }
      opened
      location {
        id
        name
        userId
      }
      impact {
        id
        status
        type
      }
      dueDate
      description
      contactType {
        id
        name
      }
      configurationItem {
        configurationType
        id
        name
      }
      commentsAndWorkNotes
      comments
      closeNotes
      businessUnit {
        id
        name
      }
      assignmentGroup {
        groupType
        id
        name
      }
      assignedTo {
        id
        name
        userId
      }
      approval {
        approvalType
        id
        name
      }
      active
    }
  }
}`;
      //console.log(gquery);
      if (isLoading) {
        const graphQlAxios = axios.create({
          baseURL: "https://localhost:7139/graphql/",
          method: "post",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        });

        await graphQlAxios
          .post("", { query: qg })
          .then((response) => {
            try {
              //setDataJson(response?.data?.data.request.items[0]);
              console.log("object");
              setData(JSON.stringify(response?.data?.data.request.items[0]));
              if (response?.data.error !== undefined) {
                setErrorData(JSON.stringify(response?.data.error));
              } else {
                setErrorData("");
              }
              setLoading(false);
            } catch (error) {
              console.log(error);
            }
            //setDataJson(response?.data?.data.request.items);
            //setData(JSON.stringify(response?.data?.data.request.items));
            if (response?.data.error !== undefined) {
              setErrorData(JSON.stringify(response?.data.error));
            } else {
              setErrorData("");
            }
            setLoading(false);
            //jsonss = JSON.stringify(response);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    })();
  });

  function inputBox() {
    return (
      <>
        <div className="w-20"></div>
      </>
    );
  }
  return (
    <div>
      <div className="flex flex-row justify-evenly gap-2">
        <div className="flex h-40 flex-col justify-end rounded-md bg-slate-200">
          <div className="flex w-full flex-row justify-end gap-2 p-2 text-right">
            <p>ID asdf</p>
            <input></input>
          </div>
          <div className="flex w-full flex-row justify-end gap-2 p-2 text-right">
            <p>ID asdf dsf dfs</p>
            <input></input>
          </div>
          <div className="flex w-full flex-row justify-end gap-2 p-2 text-right">
            <p>ID asdf lkjsa aslkdfjlkas d</p>
            <input></input>
          </div>
        </div>
        <div className="w-10"></div>
        <div className="h-40 w-32 rounded-md bg-slate-500"></div>
      </div>
      {isLoading ? "Loading Data....." : data}
    </div>
  );
}
