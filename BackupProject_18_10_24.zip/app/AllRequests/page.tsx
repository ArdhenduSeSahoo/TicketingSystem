import * as React from "react";
import { MainStoreProvider } from "../component/MainStoreProvider";
import InitDataLoading from "../component/InitDataLoading";
import FilterPanelInitDataLoader from "../component/FilterComponent/FilterPanel_InitDataLoader";
import FilterPanel from "../component/FilterComponent/FilterPanel";

import TablePagingComponent from "../component/TablePaggingComponent";
import { PageDataType } from "@/lib/DefaultData/PageDataType";
import IncidentTable from "../component/IncidentTable";

// export interface IAllRequestsProps {}

export default function AllRequests() {
  const typeOfFilter = PageDataType.RequestData;
  return (
    <>
      <MainStoreProvider>
        <InitDataLoading filterType={typeOfFilter} />

        <div className="flex-shrink">
          <FilterPanelInitDataLoader filterType={typeOfFilter} />
          <FilterPanel typeOfFilter={typeOfFilter} />
        </div>

        <div className="h-96 grow overflow-scroll">
          <IncidentTable pageDataType={typeOfFilter}></IncidentTable>
        </div>
        <div className="flex flex-none justify-center">
          <TablePagingComponent pageDataType={typeOfFilter} />
        </div>
      </MainStoreProvider>
    </>
  );
}
