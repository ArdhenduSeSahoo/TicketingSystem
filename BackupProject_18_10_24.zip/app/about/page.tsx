export default function Page() {
  return (
    <div>
      <h1>Ardhendu</h1>
    </div>
  );
}
