"use client";
import React, { useState } from "react";
import axios from "axios";
import { Tab, TabGroup, TabList, TabPanel, TabPanels } from "@headlessui/react";
import Image from "next/image";

export interface IFileUploadProps {}

export default function FileUpload(props: IFileUploadProps) {
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!selectedFile) {
      alert("Please select a file");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("file", selectedFile);

      const response = await axios.post(
        "https://localhost:7139/api/Files",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      );

      console.log("File uploaded successfully:", response.data);
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  const olddesign = (
    <div>
      <h2>File Upload</h2>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} />
        <button type="submit">Upload</button>
      </form>
    </div>
  );
  const tabnames: string[] = [
    "Incident file upload",
    "Request file upload",
    "Running background service status",
  ];
  return (
    <>
      <div className="grow bg-slate-300">
        <TabGroup className="mt-5">
          <div></div>
          <TabList className="mx-10 flex gap-4">
            {tabnames.map((itm) => {
              return (
                <>
                  <Tab
                    key={itm}
                    className="rounded-full bg-blue-600 px-3 py-1 text-sm/6 font-semibold text-white focus:outline-none data-[hover]:bg-purple-500 data-[selected]:bg-purple-600 data-[selected]:data-[hover]:bg-purple-500 data-[focus]:outline-1 data-[focus]:outline-white"
                  >
                    {itm}
                  </Tab>
                </>
              );
            })}
          </TabList>
          <TabPanels className="mt-3 flex h-fit flex-row bg-slate-400">
            <TabPanel className="flex max-h-full grow justify-center bg-slate-50">
              <div className="card card-compact w-96 bg-base-100 shadow-xl">
                <figure>
                  <Image
                    src={"/images/baner1.jpg"}
                    alt="baner"
                    width={400}
                    height={150}
                    className=""
                  ></Image>
                  {/* <img
                    src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.webp"
                    alt="Shoes"
                  /> */}
                </figure>
                <div className="card-body">
                  <h2 className="card-title">Upload list of Incident File</h2>
                  <p>File format should be xlsx</p>
                  <form onSubmit={handleSubmit}>
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="file-input file-input-bordered file-input-primary h-8 w-full max-w-xs"
                    />

                    <div className="mt-3 flex justify-end">
                      <div className="card-actions justify-end">
                        <button
                          type="submit"
                          className="btn btn-primary btn-sm"
                        >
                          Upload
                        </button>
                      </div>
                    </div>
                  </form>
                  <div>
                    <div role="alert" className="alert alert-error">
                      <span>Error! Task failed successfully.</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabPanel>
            <TabPanel>Content 2</TabPanel>
            <TabPanel>Content 3</TabPanel>
          </TabPanels>
        </TabGroup>
      </div>
    </>
  );
  return (
    <TabGroup className="mt-5">
      <div></div>
      <TabList className="mx-10 flex gap-4">
        {tabnames.map((itm) => {
          return (
            <>
              <Tab
                key={itm}
                className="rounded-full bg-blue-600 px-3 py-1 text-sm/6 font-semibold text-white focus:outline-none data-[hover]:bg-purple-500 data-[selected]:bg-purple-600 data-[selected]:data-[hover]:bg-purple-500 data-[focus]:outline-1 data-[focus]:outline-white"
              >
                {itm}
              </Tab>
            </>
          );
        })}
      </TabList>
      <TabPanels className="h-full bg-slate-400 px-5">
        <TabPanel className="">Content 1</TabPanel>
        <TabPanel>Content 2</TabPanel>
        <TabPanel>Content 3</TabPanel>
      </TabPanels>
    </TabGroup>
  );
}
