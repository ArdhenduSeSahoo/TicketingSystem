"use client";
import { useEffect, useState } from "react";
import { CommentStringFilter } from "../../CommentFilterString";
import { WorkNoteFilterString } from "../../WorkNoteFilterString";
import axios from "axios";
import { Api_URL } from "@/lib/DefaultData/ApplicationSetupKeys";

export default function Page({ params }: { params: { id: string } }) {
  // const [data, setData] = useState("");
  // const [ErrorData, setErrorData] = useState("");
  // const [dataJson, setDataJson] = useState(Object);
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const qg = `query {
  request(order: {}, skip: 0, take: 100, where: { and: {  number: { eq: "${params.id}", }, }, or: {  } }) {
    items {
      id
      number
      shortDescription
      stage {
        id
        name
      }
      state {
        id
        name
        type
      }
      urgency {
        id
        status
        type
      }
      specialInstructions
      requestState {
        id
        name
      }
      requestedFor {
        id
        name
        userId
      }
      priority {
        id
        name
        type
      }
      price
      openedBy {
        id
        name
        userId
      }
      opened
      location {
        id
        name
        userId
      }
      impact {
        id
        status
        type
      }
      dueDate
      description
      contactType {
        id
        name
      }
      configurationItem {
        configurationType
        id
        name
      }
      commentsAndWorkNotes
      comments
      closeNotes
      businessUnit {
        id
        name
      }
      assignmentGroup {
        groupType
        id
        name
      }
      assignedTo {
        id
        name
        userId
      }
      approval {
        approvalType
        id
        name
      }
      active
    }
  }
}`;
      if (isLoading) {
        // const gres = await AxiosGraphQlPostCall(qg);
        // console.log(gres);

        // const errorMessage = hasResponseError(gres);
        // console.log(errorMessage);
        // console.log(response);
        // AxiosGraphQlPostCall(qg).then((res) => {
        //   console.log(res);
        // });
        // if (errorMessage === "") {
        //   setDataJson(response?.data?.data.request.items[0]);
        // }
        const graphQlAxios = axios.create({
          baseURL: Api_URL,
          method: "post",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        });
        await graphQlAxios
          .post("", { query: qg })
          .then((response) => {
            try {
              setData(JSON.stringify(response?.data?.data.request.items[0]));
              console.log(response);
              if (response?.data.error !== undefined) {
                setErrorData(JSON.stringify(response?.data.error));
              } else {
                setDataJson(response?.data?.data.request.items[0]);
                console.log(response);
              }
              setLoading(false);
            } catch (error) {
              console.log(error);
            }
            // setDataJson(response?.data?.data.request.items);
            // setData(JSON.stringify(response?.data?.data.request.items));
            // if (response?.data.error !== undefined) {
            //   setErrorData(JSON.stringify(response?.data.error));
            // } else {
            //   setErrorData("");
            // }
            // setLoading(false);
            //jsonss = JSON.stringify(response);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    })();
  }, []);
  const comment_str = `"02-09-2024 06:17:45 - Agustin Medero Calvo (Comments)
Hi @Alvaro Rana Alba, 

The statistics were launched again. Please, could you confirm if now it's alright? Thanks!

01-09-2024 11:25:49 - Alvaro Rana Alba (Comments)
Good day,

Please relaunch again not updated accordingly

01-09-2024 11:06:42 - Daniel Toscano Fajardo (Comments)
Crane statistics have been relaunched

"
`;
  const worknote = `17-09-2024 09:18:55 - Rohit Thakur (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 10th Sept 2024:
================
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case.

11th - 13th Sept 2024:
=================
-As per the update from LC over Group chat, this site is under construction and no business activities for the next three months.
-LC will check and confirm the primary checks next week.

14-17th sept 2024
===============
-As per update on MS teams group chat, this site is under construction and no business activities for the next three months.
-As discussed with site LC, will check the AP and share checks next week.
- pending update from Site LC.

13-09-2024 09:29:19 - Akash Gunjal (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 10th Sept 2024:
================
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case.

11th - 13th Sept 2024:
=================
-As per the update from LC over Group chat, this site is under construction and no business activities for the next three months.
-LC will check and confirm the primary checks next week.

12-09-2024 11:29:15 - Pratik Gundale (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 10th Sept 2024:
================
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case.

11th - 12th Sept 2024:
=================
-As per the update from LC over Group chat, this site is under construction and no business activities for the next three months.
-LC will check and confirm the primary checks next week.

11-09-2024 06:58:01 - Pratik Gundale (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 10th Sept 2024:
================
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case. 

11th Sept 2024:
================= 
-As per the update from LC over Group chat, this site is under construction and no business activities for the next three months.
-LC will check and confirm the primary checks next week.

10-09-2024 07:30:12 - Pratik Gundale (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 10th Sept 2024:
================
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case.

09-09-2024 15:34:02 - Pratik Gundale (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 9th Sept 2024:
================ 
-Awaiting progressive update from LC regarding primary checks.
- Network team has applied strike rule on this case.

09-09-2024 15:33:25 - Pratik Gundale (Work notes)
""Detailed ticket summary.

01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for primary checks.
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

5th to 9th Sept 2024:
================ 
-Awaiting progressive update from LC regarding primary checks.

06-09-2024 13:43:02 - Raveen Kumar (Work notes)
""Detailed ticket summary.
  
01st Sept 2024
===========
- Network L1 received device down alert from SW.
- Network L1 team created INC and marked mail to site LC for prechecks.
- Network L1 team waiting for prechecks from Site LC.

02nd Sept 2024
===========
- Network L1 team waiting for prechecks from Site LC.

03rd Sept 2024
===========
- Network L1 team waiting for prechecks from Site LC.

04th Sept 2024
===========
- Site LC confirmed that site is under construction and will perform the prechecks in afternoon.- Network L1 team waiting for prechecks from Site LC.

05th Sept 2024
===========
- Network L1 team waiting for prechecks from Site LC.

06th Sept 2024
===========
- Network L1 team waiting for prechecks from Site LC.""

01-09-2024 04:57:37 - Pratiksha Pawar (Work notes)
Awaiting primary checks
`;

  function inputbox(parm: string) {
    return (
      <>
        <div className="border-gray-350 bordered flex h-8 min-w-72 border-spacing-3 items-center rounded-md border bg-gray-100 px-2 text-left">
          <p className="">{parm}</p>
        </div>
      </>
    );
  }
  function itemRow(prop: { lablename: string; lblvalue: string }) {
    return (
      <div className="flex flex-row justify-end gap-2">
        {prop.lablename}
        {inputbox(prop.lblvalue)}
      </div>
    );
  }
  const pagedesign = (
    <>
      <div className="flex w-full flex-col items-center justify-center pt-10">
        <div className="flex flex-col items-center justify-center rounded-lg border border-red-700 bg-slate-50">
          <div className="flex border-spacing-1 rounded-md p-4">
            <div className="flex w-full flex-row justify-between">
              <div className="flex flex-col gap-2">
                {/* <button className="btn btn-success" onClick={btn_click}>
                  Click
                </button> */}
                {itemRow({ lablename: "ID", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Items", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Request",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({ lablename: "Request for", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Location", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Business Unit",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({
                  lablename: "Configuration item",
                  lblvalue: "Ardhendu",
                })}
              </div>
              <div className="flex flex-col gap-2">
                {itemRow({ lablename: "Opened", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Opened by", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "State", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Stage", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Assignment group",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({ lablename: "Assigned to", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Impact", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Urgency", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Priority", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Approval", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Contact Type", lblvalue: "Ardhendu" })}
              </div>
            </div>
          </div>
          <div className="m-2 flex border-spacing-1 flex-col gap-2 rounded-md border border-red-700 p-2">
            <div className="flex flex-row justify-end gap-2">
              Description:
              <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 items-center rounded-md bg-gray-100 px-2 text-left">
                <p className="">
                  If you need to use a one-off width value that doesn’t make
                  sense to include in your theme, use square brackets to
                  generate a property on the fly using any arbitrary value. If
                  you need to use a one-off width value that doesn’t make sense
                  to include in your theme, use square brackets to generate a
                  property on the fly using any arbitrary value.
                </p>
              </div>
            </div>
            <div className="flex flex-row justify-center gap-2">
              Short Description:
              <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 items-center rounded-md bg-gray-100 px-2 text-left">
                <p className="">
                  If you need to use a one-off width value that doesn’t make
                  sense to include in your theme, use square brackets to
                  generate a property on the fly using any arbitrary value. If
                  you need to use a one-off width value that doesn’t make sense
                  to include in your theme, use square brackets to generate a
                  property on the fly using any arbitrary value.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-2 flex min-w-60 flex-col items-center justify-center rounded-lg border border-red-700 p-2">
          <div className="flex flex-col gap-2">
            <p className="font-semibold">Comments:</p>
            {CommentStringFilter(comment_str).map((itm) => {
              return (
                <>
                  <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 flex-col items-start rounded-md bg-gray-100 px-2 text-left">
                    <div className="flex w-full flex-row justify-between">
                      <div className="pl-2 font-semibold">{itm.userName}</div>
                      <div className="pr-2">{itm.dateTime}</div>
                    </div>
                    <p className="">{itm.commentsOfUser}</p>
                  </div>
                </>
              );
            })}
          </div>
        </div>
        <div className="mt-2 flex min-w-60 flex-col items-center justify-center rounded-lg border border-red-700 p-2">
          <div className="flex flex-col gap-2">
            <p className="font-semibold">Work Note:</p>
            {WorkNoteFilterString(worknote).map((itm) => {
              return (
                <>
                  <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 flex-col items-start rounded-md bg-gray-100 px-2 text-left">
                    <div className="flex w-full flex-row justify-between">
                      <div className="pl-2 font-semibold">{itm.userName}</div>
                      <div className="pr-2">{itm.dateTime}</div>
                    </div>
                    <p className="">{itm.commentsOfUser}</p>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
  return pagedesign;
}
