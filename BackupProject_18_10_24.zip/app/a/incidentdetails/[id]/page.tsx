"use client";

export default function Page({ params }: { params: { id: string } }) {
  function btn_click() {
    const comment_str = `"02-09-2024 06:17:45 - Agustin Medero Calvo (Comments)
Hi @Alvaro Rana Alba, 

The statistics were launched again. Please, could you confirm if now it's alright? Thanks!

01-09-2024 11:25:49 - Alvaro Rana Alba (Comments)
Good day,

Please relaunch again not updated accordingly

01-09-2024 11:06:42 - Daniel Toscano Fajardo (Comments)
Crane statistics have been relaunched

"
`;
    const searchTerm = "(Comments)";
    const indexOfFirst = comment_str.indexOf(searchTerm);

    const secondIndexof_comment = comment_str.indexOf(
      searchTerm,
      indexOfFirst + 10,
    );
    const firstcomment = comment_str.substring(0, secondIndexof_comment);
    const blank_position = firstcomment.lastIndexOf("-");
    const first_comment = comment_str.substring(0, blank_position - 20);
    console.log(indexOfFirst);
    console.log(first_comment);
    console.log(blank_position);

    //console.log(comment_str.substring(0, indexOfFirst));
  }
  function inputbox(parm: string) {
    return (
      <>
        <div className="bordered flex h-8 min-w-72 border-spacing-3 items-center rounded-md border border-black bg-gray-100 px-2 text-left">
          <p className="">{parm}</p>
        </div>
      </>
    );
  }
  function itemRow(prop: { lablename: string; lblvalue: string }) {
    return (
      <div className="flex flex-row justify-end gap-2">
        {prop.lablename}
        {inputbox(prop.lblvalue)}
      </div>
    );
  }
  const pagedesign = (
    <>
      <div className="flex w-full flex-col items-center justify-center pt-10">
        <div className="flex flex-col items-center justify-center rounded-lg border border-red-700 bg-slate-50">
          <div className="flex border-spacing-1 rounded-md p-4">
            <div className="flex flex-row justify-between">
              <div className="flex flex-col gap-2">
                <button className="btn btn-success" onClick={btn_click}>
                  Click
                </button>
                {itemRow({ lablename: "ID", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Items", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Request",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({ lablename: "Request for", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Location", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Business Unit",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({
                  lablename: "Configuration item",
                  lblvalue: "Ardhendu",
                })}
              </div>
              <div className="w-24"></div>
              <div className="flex flex-col gap-2">
                {itemRow({ lablename: "Opened", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Opened by", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "State", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Stage", lblvalue: "Ardhendu" })}
                {itemRow({
                  lablename: "Assignment group",
                  lblvalue: "Ardhendu",
                })}
                {itemRow({ lablename: "Assigned to", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Impact", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Urgency", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Priority", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Approval", lblvalue: "Ardhendu" })}
                {itemRow({ lablename: "Contact Type", lblvalue: "Ardhendu" })}
              </div>
            </div>
          </div>
          <div className="m-2 flex border-spacing-1 flex-col gap-2 rounded-md border border-red-700 p-2">
            <div className="flex flex-row justify-end gap-2">
              Description:
              <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 items-center rounded-md bg-gray-100 px-2 text-left">
                <p className="">
                  If you need to use a one-off width value that doesn’t make
                  sense to include in your theme, use square brackets to
                  generate a property on the fly using any arbitrary value. If
                  you need to use a one-off width value that doesn’t make sense
                  to include in your theme, use square brackets to generate a
                  property on the fly using any arbitrary value.
                </p>
              </div>
            </div>
            <div className="flex flex-row justify-center gap-2">
              Short Description:
              <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 items-center rounded-md bg-gray-100 px-2 text-left">
                <p className="">
                  If you need to use a one-off width value that doesn’t make
                  sense to include in your theme, use square brackets to
                  generate a property on the fly using any arbitrary value. If
                  you need to use a one-off width value that doesn’t make sense
                  to include in your theme, use square brackets to generate a
                  property on the fly using any arbitrary value.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center rounded-lg border border-red-700">
          <div className="flex flex-row justify-end gap-2">
            Description:
            <div className="bordered flex min-w-[60rem] max-w-[70rem] border-spacing-2 items-center rounded-md bg-gray-100 px-2 text-left">
              <p className="">
                If you need to use a one-off width value that doesn’t make sense
                to include in your theme, use square brackets to generate a
                property on the fly using any arbitrary value. If you need to
                use a one-off width value that doesn’t make sense to include in
                your theme, use square brackets to generate a property on the
                fly using any arbitrary value.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
  return pagedesign;
}
