"use client";

import {
  FilterColumnValue,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import { useAppDispatch } from "@/lib/Redux/Hooks/HomePageHook";
import { changeFilterColumn } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";

export interface IMainDropDownItemProps {
  filterDataColumn: FilterColumnValue;
  filterRow: FilterUIData;
}

export default function MainDropDownItem(props: IMainDropDownItemProps) {
  const dispatch = useAppDispatch();

  const opetiondesign = (
    <option value={props.filterDataColumn.name}>
      {props.filterDataColumn.name}
    </option>
  );
  return opetiondesign;
}
