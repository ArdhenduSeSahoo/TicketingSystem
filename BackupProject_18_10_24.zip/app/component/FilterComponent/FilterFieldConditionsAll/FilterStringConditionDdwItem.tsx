"use client";

import {
  FilterStringCondition,
  FilterUIData,
} from "@/lib/Models/FilterModels/FilterModels";
import { useAppDispatch } from "@/lib/Redux/Hooks/HomePageHook";
import { changeFilterCondition } from "@/lib/Redux/Slices/commonSlices/FilterUIDataSlice";

export interface IFilterStringConditionDdwItem {
  filterDataColumn: FilterStringCondition;
  filterRow: FilterUIData;
}

export default function FilterStringConditionDdwItem(
  props: IFilterStringConditionDdwItem,
) {
  function item_click() {}
  const old_design = (
    <li
      onClick={item_click}
      className="flex items-start justify-start overflow-hidden rounded-lg px-2 text-start hover:bg-gray-200"
    >
      {props.filterDataColumn.name}
    </li>
  );
  const new_design = (
    <>
      <option value={props.filterDataColumn.name}>
        {props.filterDataColumn.name}
      </option>
    </>
  );
  return new_design;
}
